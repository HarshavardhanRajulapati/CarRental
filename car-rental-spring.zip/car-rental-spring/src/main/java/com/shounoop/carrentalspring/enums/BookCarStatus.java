package com.shounoop.carrentalspring.enums;

public enum BookCarStatus {
    PENDING, APPROVED, REJECTED
}
