package com.shounoop.carrentalspring.dto;

import lombok.Data;

import java.util.List;

@Data
public class CarDtoListDto {
    private List<CarDto> carDtoList;
}
