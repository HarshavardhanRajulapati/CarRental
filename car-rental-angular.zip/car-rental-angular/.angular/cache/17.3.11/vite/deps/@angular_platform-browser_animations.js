import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-RAQMVCSR.js";
import "./chunk-XFH6SMI6.js";
import "./chunk-VAJNTB5A.js";
import "./chunk-TBBVKXDU.js";
import "./chunk-LUBQWU5S.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-XYHDKGPD.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
