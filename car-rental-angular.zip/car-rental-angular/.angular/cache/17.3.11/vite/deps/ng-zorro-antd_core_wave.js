import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-LIPE2S3G.js";
import "./chunk-COTGJWJG.js";
import "./chunk-RAQMVCSR.js";
import "./chunk-XFH6SMI6.js";
import "./chunk-VAJNTB5A.js";
import "./chunk-TBBVKXDU.js";
import "./chunk-LUBQWU5S.js";
import "./chunk-XYHDKGPD.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
//# sourceMappingURL=ng-zorro-antd_core_wave.js.map
