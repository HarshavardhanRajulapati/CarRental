import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-J5PVIR53.js";
import "./chunk-XYHDKGPD.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
//# sourceMappingURL=ng-zorro-antd_core_transition-patch.js.map
